"""LocalScore - CLI benchmarking tool for measuring LLM inference performance."""

__version__ = "1.0.0"
__author__ = "Mozilla Foundation"
