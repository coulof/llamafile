"""Tests for LocalScore Python."""
